<?php
if(isset($_POST["city"])) {
    $conn = new mysqli("localhost", "root", "", "kwiaciarnia");
    $city = $_POST["city"];
    $result = $conn->query("SELECT nazwa, ulica FROM kwiaciarnie WHERE miasto = \"$city\";")->fetch_row();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Kwiaty</title>
    <link rel="stylesheet" href="styl3.css">
</head>
<body>
    <header>
        <h1>Grupa Polskich Kwiaciarni</h1>
    </header>
    <main>
        <aside>
            <h2>Menu</h2>
            <ol>
                <li><a href="index.html">Strona główna</a></li>
                <li><a href="https://kwiaty.pl/" target="_blank">Rozpoznaj kwiaty</a></li>
                <li><a href="znajdz.php">Znajdź kwiaciarnię</a>
                    <ul>
                        <li>w Warszawie</li>
                        <li>w Malborku</li>
                        <li>w Poznaniu</li>
                    </ul>
                </li>
            </ol>
        </aside>
        <article>
            <h2>Znajdź kwiaciarnię</h2>
            <form action="#" method="post">
                <label>Podaj nazwę miasta: <input type="text" name="city"></label>
                <button type="submit">SPRAWDŹ</button>
                <?php
                    if (isset($result)) {
                        echo "<h3>$result[0], $result[1]</h3>";
                    }
                ?>
            </form>
        </article>
    </main>
    <footer>
        <p>Stronę opracował: lkata</p>
    </footer>
</body>
</html>